#include "kernel_operator.h"

constexpr uint32_t BUFFER_NUM = 2;

class VecAdd{
public:
    __aicore__ inline VecAdd(){}        //Initialize memory
    __aicore__ inline void Init(GM_ADDR x, GM_ADDR y, GM_ADDR z, uint32_t bigCoreNum, uint32_t bigTotalLen,
                                uint32_t bigTailNum, uint32_t smallTotalLen, uint32_t smallTailNum, uint32_ttileNum, uint32_t tileDataNum){
        uint32_t offset = bigTotalLen * AscendC::GetBlockIdx();
        this->tileNum = tileNum;
        this->tileDataNum = tileDataNum;
        // allocate global memory
        if(AscendC::GetBlockIdx() < bigCoreNum){
            this->tileLength = bigTotalLen;
            this->tailDataNum = bigTailNum;
            xGm.SetGlobalBuffer((__gm__ float*)x + offset, bigTotalLen);
            yGm.SetGlobalBuffer((__gm__ float*)x + offset, bigTotalLen);
            zGm.SetGlobalBuffer((__gm__ float*)x + offset, bigTotalLen);
        }
        else{
            this->tileLength = smallTotalLen;
            this->tailDataNum = smallTailNum;
            xGm.SetGlobalBuffer((__gm__ float*)x + offset - (bigTailNum - smallTailNum) * (AscendC::GetBlockIdx()- bigCoreNum), smallTotalLen);
            yGm.SetGlobalBuffer((__gm__ float*)x + offset - (bigTailNum - smallTailNum) * (AscendC::GetBlockIdx()- bigCoreNum), smallTotalLen);
            zGm.SetGlobalBuffer((__gm__ float*)x + offset - (bigTailNum - smallTailNum) * (AscendC::GetBlockIdx()- bigCoreNum), smallTotalLen);
        }
        // allocate memory to TQue obj
        pipe.InitBuffer(inQueueX, BUFFER_NUM, this->tileDataNum * sizeof(float));
        pipe.InitBuffer(inQueueY, BUFFER_NUM, this->tileDataNum * sizeof(float));
        pipe.InitBuffer(outQueueZ, BUFFER_NUM, this->tileDataNum * sizeof(float));
    }
    __aicore__ inline void Process(){
        int32_t loopCount = this->tileNum;
        this->transferDataNum = this->tileDataNum;
        for(int32_t i = 0; i < loopCount; i++){
            if(i == this->tileNum - 1){ this->transferDataNum = this->tailDataNum; }
            CopyIn(i);
            Compute(i);
            CopyOut(i);
        }
    }
private:
    __aicore__ inline void CopyIn(int32_t progress){
        AscendC::LocalTensor<float> xLocal = inQueueX.AllocTensor<float>();
        AscendC::LocalTensor<float> yLocal = inQueueY.AllocTensor<float>();
        AscendC::DataCopy(xLocal, xGm[progress * this->tileDataNum], this->transferDataNum); // what, where, how many
        AscendC::DataCopy(yLocal, yGm[progress * this->tileDataNum], this->transferDataNum);
        inQueueX.EnQue(xLocal);
        inQueueY.EnQue(yLocal);
    }
    __aicore__ inline void Compute(int32_t progress){
        AscendC::LocalTensor<float> xLocal = inQueueX.DeQue<float>();
        AscendC::LocalTensor<float> yLocal = inQueueX.DeQue<float>();
        AscendC::LocalTensor<float> zLocal = outQueueZ.AllocTensor<float>();
        AscendC::Add(zLocal, xLocal, yLocal, this->transferDataNum);
        outQueueZ.EnQue(zLocal);
        inQueueX.FreeTensor(xLocal);
        inQueueY.FreeTensor(yLocal);
    }
    __aicore__ inline void CopyOut(int32_t progress){
        AscendC::LocalTensor<float> zLocal = outQueueZ.DeQue<float>();
        AscendC::DataCopy(zGm[progress * this->tileDataNum], zLocal, this->transferDataNum);
        outQueueZ.FreeTensor(zLocal);
    }
private:
    // memory management obj
    AscendC::TPipe pipe;
    // queue management obj
    AscendC::TQue<AscendC::QuePosition::VECIN, BUFFER_NUM> inQueueX, inQueueY;
    AscendC::TQue<AscendC::QuePosition::VECOUT, BUFFER_NUM> outQueueZ;
    // GM address management obj
    AscendC::GlobalTensor<float> xGm;
    AscendC::GlobalTensor<float> yGm;
    AscendC::GlobalTensor<float> zGm;
    // member var
    uint32_t tileLength;
    uint32_t tileNum;
    uint32_t tileDataNum;
    uint32_t transferDataNum;
    uint32_t tailDataNum;
};

extern "C" __global__ __aicore__ void vec_add(GM_ADDR x, GM_ADDR y, GM_ADDR z, GM_ADDR workspace, GM_ADDR tiling) {
    GET_TILING_DATA(tiling_data, tiling);
    // TODO: user kernel impl
    VecAdd op;
    op.Init(x, y, z, tiling_data.bigCoreNum, tiling_data.bigTotalLen, tiling_data.bigTailNum,
            tiling_data.smallTotalLen, tiling_data.smallTailNum, tiling_data.tileNum, tiling_data.tileDataNum);
    op.Process();
}